package com.ramesh.cs;

public class CreateCanvas implements Command{
	private String name;
	private String shortName;
	private int x;
	private int y;
	private static final int INSTRUCTION_LENGTH = 3;
	
	public CreateCanvas() {
		this.name = "CreateCanvas" ;
		this.shortName = "C";
	}
	
	public int execute(Canvas canvas) {
		if (canvas != null) {
			return canvas.init(this.x, this.y);
		}
		return 1;
	}

	public String aboutCommand() {		
		return this.name + " : " + "C w h	       :Should create a new canvas of width w and height h.";
	}

	public String getName() {		
		return this.name;
	}
	
	public String getShortName() {		
		return this.shortName;
	}


	public boolean validateAndSetInstructions(String c) {
		String[] list = c.split(" ");
		if (list.length == INSTRUCTION_LENGTH && list[0].equals(this.shortName)) {
			try {
				this.x =Integer.parseInt(list[1]) ;
				this.y =Integer.parseInt(list[2]) ; 
				return true;
			} catch (Exception e) {
				System.out.println("Wrong format for " + this.name + " command, required format: ");
				System.out.println(aboutCommand());
				return false;
			}		
		} else {
			System.out.println("Wrong format for " + this.name + " command, required format: ");
			System.out.println(aboutCommand());
			return false;
		}
	}
	
	

}
