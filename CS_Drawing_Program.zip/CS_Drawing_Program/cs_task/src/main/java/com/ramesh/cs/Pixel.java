package com.ramesh.cs;

public class Pixel {
	public Pixel(int x1, int y1) {
		this.x=x1;
		this.y= y1;
	}
	int x;
	int y;
	char c;
}
