package com.ramesh.cs;

import java.util.ArrayList;

/**
 * @author rameshw
 *
 */
public class App 
{
    public static void main( String[] args ) {
    	CommandProcessor cp = new CommandProcessor();
    	init(cp.getCommandsListAvailable());
    	cp.start();
    }

    private static void init (ArrayList<Command> commandsListAvailable) {
    	commandsListAvailable.add(new CreateCanvas());
    	commandsListAvailable.add(new Quit());
    	commandsListAvailable.add(new Line());
    	commandsListAvailable.add(new Rectangle());
    	commandsListAvailable.add(new Fill());
    }
    
	
}
