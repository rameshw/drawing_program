package com.ramesh.cs;

import java.util.ArrayDeque;
import java.util.HashMap;

public class Fill implements Command{
	private String name;
	private String shortName;
	private int x1;
	private int y1;
	private char c;
	private static final int INSTRUCTION_LENGTH = 4;
	
	public Fill(){
		this.name = "Fill";
		this.shortName = "B";
	} 
	
	public int execute(Canvas canvas) {
		if (canvas!=null && canvas.validateLocation(x1, y1)){
			//BFS
			ArrayDeque<Pixel> q = new ArrayDeque<Pixel>();
			HashMap<String, Pixel> seen = new HashMap<String, Pixel>();
			q.add(new Pixel(x1,y1));
			char selectedPixel = canvas.getPixel(x1, y1);
			for(;;){
				if (q.isEmpty()) {
					break;
				}
				Pixel now = q.poll();
				if (canvas.validateLocation(now.x, now.y) && canvas.getPixel(now.x, now.y)==selectedPixel && !seen.containsKey(Integer.toString(now.x)+Integer.toString(now.y))) {
					canvas.updatePixel(now.x,now.y, c);
				}		
				//up
				if (canvas.validateLocation(now.x, now.y-1) && canvas.getPixel(now.x, now.y-1)==selectedPixel && !seen.containsKey(Integer.toString(now.x)+Integer.toString(now.y-1)))  {
					q.offer(new Pixel(now.x,now.y-1));
					canvas.updatePixel(now.x,now.y-1, c);
				}
				//down
				if (canvas.validateLocation(now.x, now.y+1) && canvas.getPixel(now.x, now.y+1)==selectedPixel && !seen.containsKey(Integer.toString(now.x)+Integer.toString(now.y+1)))  {
					q.offer(new Pixel(now.x,now.y+1));
					canvas.updatePixel(now.x,now.y+1, c);
				}
				//left
				if (canvas.validateLocation(now.x-1, now.y) && canvas.getPixel(now.x-1, now.y)==selectedPixel && !seen.containsKey(Integer.toString(now.x-1)+Integer.toString(now.y)))  {
					q.offer(new Pixel(now.x-1,now.y));
					canvas.updatePixel(now.x-1,now.y, c);
				}
				//right
				if (canvas.validateLocation(now.x+1, now.y) && canvas.getPixel(now.x+1, now.y)==selectedPixel && !seen.containsKey(Integer.toString(now.x+1)+Integer.toString(now.y)))  {
					q.offer(new Pixel(now.x+1,now.y));
					canvas.updatePixel(now.x+1,now.y, c);
				}
				seen.put(Integer.toString(now.x)+Integer.toString(now.y), now);	
				
			}
			return 0;
		} else {
			System.out.println("Invalid location!");
			return 1;
		}
		
	}

	public String aboutCommand() {
		return this.name + " 	     : " + "B x y c         :Should fill the entire area connected to (x,y) with 'colour' c.";
	}

	public String getName() {
		return this.name;
	}

	public String getShortName() {
		return this.shortName;
	}

	public boolean validateAndSetInstructions(String c) {
		String[] list = c.split(" ");
		if (list.length == INSTRUCTION_LENGTH && list[0].equals(this.shortName)) {
			try {
				this.x1 = Integer.parseInt(list[1]) ;
				this.y1 = Integer.parseInt(list[2]) ; 
				if (list[3].length() != 1) {
					throw new Exception();
				}
				this.c = list[3].charAt(0);
				return true;
			} catch (Exception e) {
				System.out.println("Wrong format for " + this.name + " command, required format: ");
				System.out.println(aboutCommand());
				return false;
			}
		} else {
			System.out.println("Wrong format for " + this.name + " command, required format: ");
			System.out.println(aboutCommand());
			return false;
		}
	}

}
