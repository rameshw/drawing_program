package com.ramesh.cs;

public class Quit implements Command{
	private String name;
	private String shortName;
	private static final int INSTRUCTION_LENGTH = 1;
	
	public Quit() {
		this.name = "Quit";
		this.shortName = "Q";
	}
	public int execute(Canvas canvas) {
		return 0;
	}

	public String aboutCommand() {
		return this.name + " 	     : " + "Q	       :Should quit the program.";
	}

	public String getName() {
		return this.name;
	}

	public String getShortName() {		
		return this.shortName;
	}

	public boolean validateAndSetInstructions(String c) {
		String[] list = c.split(" ");
		if (list.length == INSTRUCTION_LENGTH && list[0].equals(this.shortName)) {
			return true;
		} else {
			System.out.println("Wrong format for " + this.name + " command, required format: ");
			System.out.println(aboutCommand());
			return false;
		}
	}
}
