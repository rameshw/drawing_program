package com.ramesh.cs;

public interface Command {
	
	int execute(Canvas canvas);
	String aboutCommand();
	String getName();
	String getShortName();
	boolean validateAndSetInstructions(String c);
	

}
