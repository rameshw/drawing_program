package com.ramesh.cs;

public class Rectangle implements Command{
	private String name;
	private String shortName;
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	private static final int INSTRUCTION_LENGTH = 5;
	
	public Rectangle(){
		this.name = "Rectangle";
		this.shortName = "R";
	} 
	public int execute(Canvas canvas) {
		if (canvas!=null && canvas.validateLocation(x1, y1) && canvas.validateLocation(x2, y2)) {
			// hor
			for (int i = Math.min(x1, x2); i <= Math.max(x1, x2); i ++) {
				canvas.updatePixel(i, y1, 'x');
			}
			for (int i = Math.min(x1, x2); i <= Math.max(x1, x2); i ++) {
				canvas.updatePixel(i, y2, 'x');
			}
			//ver
			for (int i = Math.min(y1, y2); i <= Math.max(y1, y2); i ++) {
				canvas.updatePixel(x1, i, 'x');
			}
			for (int i = Math.min(y1, y2); i <= Math.max(y1, y2); i ++) {
				canvas.updatePixel(x2, i, 'x');
			}
			return 0;
		} else {
			System.out.println("Invalid start or end point!");
			return 1;
		}
		
	}

	public String aboutCommand() {
		return this.name + "    : " + "R x1 y1 x2 y2   :Should create a new rectangle, whose upper left corner is (x1,y1) and lower right corner is (x2,y2).";
	}

	public String getName() {
		return this.name;
	}

	public String getShortName() {
		return this.shortName;
	}

	public boolean validateAndSetInstructions(String c) {
		String[] list = c.split(" ");
		if (list.length == INSTRUCTION_LENGTH && list[0].equals(this.shortName)) {
			try {
				this.x1 =Integer.parseInt(list[1]) ;
				this.y1 =Integer.parseInt(list[2]) ; 
				this.x2 =Integer.parseInt(list[3]) ;
				this.y2 =Integer.parseInt(list[4]) ;
				return true;
			} catch (Exception e) {
				System.out.println("Wrong format for " + this.name + " command, required format: ");
				System.out.println(aboutCommand());
				return false;
			}
		} else {
			System.out.println("Wrong format for " + this.name + " command, required format: ");
			System.out.println(aboutCommand());
			return false;
		}
	}

}
