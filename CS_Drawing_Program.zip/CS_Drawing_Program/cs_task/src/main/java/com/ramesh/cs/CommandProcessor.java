package com.ramesh.cs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class CommandProcessor {
	ArrayList<Command> commandsListAvailable = new ArrayList<Command>();
	// Saving if restoring canvas state is required
	ArrayList<Command> commandsListRun = new ArrayList<Command>();
	
	public ArrayList<Command> getCommandsListAvailable() {
		return this.commandsListAvailable;
	}
	
	public  void printOptions() {
		System.out.println( "" );
		System.out.println( "The following commands are available: " );
		for (Command c : this.commandsListAvailable) {
			System.out.println(c.aboutCommand());
		}
		
	}

	public  Command parseCommand(String command) {
		String[] list = command.split(" ");
		//find matching command
		Command match=null;
		for (Command c : commandsListAvailable) {
			if (list[0].equals(c.getShortName())) {
				try {
					match = c.getClass().newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (match == null) {
			System.out.println( "Invalid Command!" );
		} else if(match.validateAndSetInstructions(command)){
			return match;
		}
		return null;	
	}
	
	public void start() {
		Canvas canvas = new Canvas();
    	Scanner scanner = new Scanner(System.in);
    	String command = "";
    	printOptions();
    	for(;;) {
    		System.out.print("Enter command: ");
    		command = scanner.nextLine();    		
    		Command c = parseCommand (command);
    		if (c == null) {
    			printOptions();
    			continue;
    		}
    		
    		if (c instanceof Quit)
    			break;
    		
    		if (this.commandsListRun.size() == 0 && !(c instanceof CreateCanvas)) {
    			System.out.println( "First Command needs to create a canvas, the command formats are:" );
    			printOptions();   			
    		} else {
    			if (c instanceof CreateCanvas) {
    				if (c.execute(canvas) == 0) {
    					for (Iterator<Command> iterator = this.commandsListAvailable.iterator(); iterator.hasNext();) {
    						Command com = iterator.next();
    					    if (com instanceof CreateCanvas) {
    					        iterator.remove();
    					    }
    					}
    				} else {
    					System.out.println( "Draw " + c.getName() + " failed!");
    				}
    			}  else {
    				if (c.execute(canvas)!=0) {
    					System.out.println( "Draw " + c.getName() + " failed!");
    				}
    			}  			
    			this.commandsListRun.add(c);
    			canvas.print();
    		}	
    	}
    	scanner.close();
	}
}
