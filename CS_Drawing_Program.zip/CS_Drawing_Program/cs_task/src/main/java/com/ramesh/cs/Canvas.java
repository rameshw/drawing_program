package com.ramesh.cs;

import java.util.Arrays;

public class Canvas {
	private char[][] canvas;

	public Canvas() {
	}

	public void print() {
		for (int i = 0; i < canvas.length; i++) {
			for (int j = 0; j < canvas[i].length; j++) {
				if (canvas[i][j] == Character.MIN_VALUE) {
					System.out.print(' ');
				} else {
					System.out.print(canvas[i][j]);
				}
			}
			System.out.println("");
		}

	}
	
	public void clear() {
		for (int i = 1; i < canvas.length-1; i++) {
			for (int j = 1; j < canvas[i].length-1; j++) {
				canvas[i][j] = Character.MIN_VALUE;
			}
		}

	}

	public int updatePixel(int i, int j, char c) {
		if (validateLocation(i, j)) {
			this.canvas[j][i] = c;
			return 0;
		} else {
			System.out.println("Coordinates (" + i + "," + j + ")" + " outside drawable area!");
			return 1;
		}

	}

	boolean validateLocation(int i, int j) {
		if (i > 0 && i < canvas[0].length - 1 && j > 0 && j < canvas.length - 1)
			return true;
		else
			return false;
	}

	public int init(int i, int j) {
		if (i > 0 && j > 0) {
			canvas = new char[j + 2][i + 2];

			// set borders
			Arrays.fill(canvas[0], '-');
			Arrays.fill(canvas[j + 1], '-');
			for (int i1 = 1; i1 < j + 1; i1++) {
				canvas[i1][0] = '|';
				canvas[i1][i + 1] = '|';
			}
			return 0;
		} else {
			System.out.println("Canvas height and width needs to be greater than 0!");
			return 1;
		}

	}
	
	public char getPixel(int i, int j) {
		return this.canvas[j][i];
	}

	public char[] getRow(int i) {
		return this.canvas[i];
	}
}
