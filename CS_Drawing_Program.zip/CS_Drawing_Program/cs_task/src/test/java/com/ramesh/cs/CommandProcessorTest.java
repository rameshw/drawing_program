package com.ramesh.cs;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;

public class CommandProcessorTest {
	CommandProcessor cp = new CommandProcessor();
	
	@Before
	public void init() {	 
		 cp.getCommandsListAvailable().add(new CreateCanvas());
		 cp.getCommandsListAvailable().add(new Quit());
		 cp.getCommandsListAvailable().add(new Line());
		 cp.getCommandsListAvailable().add(new Rectangle());
		 cp.getCommandsListAvailable().add(new Fill());
	}
		
	@Test
	public void parserTest(){
		//check if valid instance is created
		assertEquals(true, cp.parseCommand("C 20 4") instanceof CreateCanvas);
		assertEquals(false, cp.parseCommand("c 20 4") instanceof CreateCanvas);
		assertEquals(true, cp.parseCommand("L 6 3 6 4") instanceof Line);
		assertEquals(false, cp.parseCommand("l 6 3 6 4") instanceof Line);
		assertEquals(true, cp.parseCommand("R 14 1 18 3") instanceof Rectangle);
		assertEquals(false, cp.parseCommand("r 14 1 18 3") instanceof Rectangle);
		assertEquals(true, cp.parseCommand("B 10 3 o") instanceof Fill);
		assertEquals(false, cp.parseCommand("b 10 3 o") instanceof Fill);
		assertEquals(true, cp.parseCommand("Q") instanceof Quit);
		assertEquals(false, cp.parseCommand("q") instanceof Quit);	
	}
	
}
