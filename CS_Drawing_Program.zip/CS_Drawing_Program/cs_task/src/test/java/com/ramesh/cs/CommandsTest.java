package com.ramesh.cs;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;


public class CommandsTest {
	private Canvas canvas;
	
	@Before
	public void init(){
		canvas = new Canvas();
		canvas.init(20,4);
	}
	
	@Test
	public void testValidationCreateCanvas() {
		Command c = new CreateCanvas();
		assertEquals(true, c.validateAndSetInstructions("C 20 4"));
		assertEquals(false, c.validateAndSetInstructions("C 20 a"));
		assertEquals(false, c.validateAndSetInstructions("C b 4"));
		assertEquals(false, c.validateAndSetInstructions("C 20"));
		assertEquals(false, c.validateAndSetInstructions("C  b"));
		assertEquals(false, c.validateAndSetInstructions("C  20  4"));
		assertEquals(false, c.validateAndSetInstructions("C"));
	}
	
	@Test
	public void testQuit() {
		Command c = new Quit();
		assertEquals(true, c.validateAndSetInstructions("Q"));
		assertEquals(true, c.validateAndSetInstructions("Q "));
		assertEquals(true, c.validateAndSetInstructions("Q  "));
		assertEquals(false, c.validateAndSetInstructions("Q  1"));
	}
	
	@Test
	public void testValidationLine() {
		Command c = new Line();
		
		assertEquals(true, c.validateAndSetInstructions("L 1 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("l 1 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("l 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("L        "));
		assertEquals(false, c.validateAndSetInstructions("L 6 3 6 a"));
		assertEquals(false, c.validateAndSetInstructions("L a 6 3 6"));
		assertEquals(false, c.validateAndSetInstructions("L 6 a 6 3"));
		assertEquals(false, c.validateAndSetInstructions("L 6 3 a 3"));
	}
	
	@Test
	public void testDrawLineHorizontal() {
		Command c = new Line();
		//Horizontal
		c.validateAndSetInstructions("L 1 2 6 2");
		c.execute(canvas);
		char[] expected = new char[22];
		expected[0] ='|';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(1));
		expected = new char[22];
		expected[0] ='|';
		expected[1] ='x';
		expected[2] ='x';
		expected[3] ='x';
		expected[4] ='x';
		expected[5] ='x';
		expected[6] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(2));
		expected = new char[22];
		expected[0] ='|';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(3));
		assertArrayEquals(expected, canvas.getRow(4));
		canvas.clear();
	}
	
	@Test
	public void testDrawLineVerical() {
		Command c = new Line();
		char[] expected = new char[22];
		//Vertical
		c.validateAndSetInstructions("L 6 3 6 4");
		c.execute(canvas);
		expected = new char[22];
		expected[0] ='|';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(1));
		expected = new char[22];
		expected[0] ='|';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(2));
		expected = new char[22];
		expected[0] ='|';
		expected[6] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(3));
		expected = new char[22];
		expected[0] ='|';
		expected[6] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(4));
		canvas.clear();
	}
	
	@Test
	public void testValidationRect() {
		Command c = new Rectangle();
		assertEquals(true, c.validateAndSetInstructions("R 1 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("r 1 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("R 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("R        "));
		assertEquals(false, c.validateAndSetInstructions("R 6 3 6 a"));
		assertEquals(false, c.validateAndSetInstructions("R a 6 3 6"));
		assertEquals(false, c.validateAndSetInstructions("R 6 a 6 3"));
		assertEquals(false, c.validateAndSetInstructions("R 6 3 a 3"));
	}
	
	@Test
	public void testDrawRect() {		
		Command c = new Rectangle();
		c.validateAndSetInstructions("R 14 1 18 3");
		c.execute(canvas);
		char[] expected = new char[22];
		expected[0] ='|';
		expected[14] ='x';
		expected[15] ='x';
		expected[16] ='x';
		expected[17] ='x';
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(1));
		expected = new char[22];
		expected[0] ='|';
		expected[14] ='x';
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(2));
		expected = new char[22];
		expected[0] ='|';
		expected[14] ='x';
		expected[15] ='x';
		expected[16] ='x';
		expected[17] ='x';
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(3));
		canvas.clear();
	}
	
	@Test
	public void testValidationFill() {
		Command c = new Fill();
		assertEquals(true, c.validateAndSetInstructions("B 1 1 c"));
		assertEquals(true, c.validateAndSetInstructions("B 1 1 1"));
		assertEquals(false, c.validateAndSetInstructions("B 1 1  "));
		assertEquals(false, c.validateAndSetInstructions("B      "));
		assertEquals(false, c.validateAndSetInstructions("b 1 1 c"));
		assertEquals(false, c.validateAndSetInstructions("B a 1 c"));
		assertEquals(false, c.validateAndSetInstructions("B 1 b c"));
		assertEquals(false, c.validateAndSetInstructions("B 1 1 abc"));
	}
	
	@Test
	public void testFillNormal() {
		Command c = new Line();
		//Horizontal
		c.validateAndSetInstructions("L 1 2 6 2");
		c.execute(canvas);
		c.validateAndSetInstructions("L 6 3 6 4");
		c.execute(canvas);
		c = new Rectangle();
		c.validateAndSetInstructions("R 14 1 18 3");
		c.execute(canvas);
		c = new Fill();
		c.validateAndSetInstructions("B 10 3 o");
		c.execute(canvas);
		char[] expected = new char[22];
		Arrays.fill(expected,'o');
		expected[0] ='|';
		expected[14] ='x';
		expected[15] ='x';
		expected[16] ='x';
		expected[17] ='x';
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(1));
		expected = new char[22];
		Arrays.fill(expected,'o');
		expected[0] ='|';
		expected[1] ='x';
		expected[2] ='x';
		expected[3] ='x';
		expected[4] ='x';
		expected[5] ='x';
		expected[6] ='x';
		expected[14] ='x';
		expected[15] =Character.MIN_VALUE;
		expected[16] =Character.MIN_VALUE;
		expected[17] =Character.MIN_VALUE;
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(2));
		expected = new char[22];
		Arrays.fill(expected,'o');
		expected[0] ='|';
		expected[1] =Character.MIN_VALUE;
		expected[2] =Character.MIN_VALUE;
		expected[3] =Character.MIN_VALUE;
		expected[4] =Character.MIN_VALUE;
		expected[5] =Character.MIN_VALUE;
		expected[6] ='x';
		expected[14] ='x';
		expected[15] ='x';
		expected[16] ='x';
		expected[17] ='x';
		expected[18] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(3));
		expected = new char[22];
		Arrays.fill(expected,'o');
		expected[0] ='|';
		expected[1] =Character.MIN_VALUE;
		expected[2] =Character.MIN_VALUE;
		expected[3] =Character.MIN_VALUE;
		expected[4] =Character.MIN_VALUE;
		expected[5] =Character.MIN_VALUE;
		expected[6] ='x';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(4));
		canvas.clear();
	}
	
	@Test
	public void testFillOnX() {
		// fill over 'x'
		Command c = new Rectangle();
		c.validateAndSetInstructions("R 14 1 18 3");
		c.execute(canvas);
		c = new Fill();
		c.validateAndSetInstructions("B 14 1 o");
		c.execute(canvas);
		char[] expected = new char[22];
		expected[0] ='|';
		expected[14] ='o';
		expected[15] ='o';
		expected[16] ='o';
		expected[17] ='o';
		expected[18] ='o';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(1));
		expected = new char[22];
		expected[0] ='|';
		expected[14] ='o';
		expected[18] ='o';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(2));
		expected = new char[22];
		expected[0] ='|';
		expected[14] ='o';
		expected[15] ='o';
		expected[16] ='o';
		expected[17] ='o';
		expected[18] ='o';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(3));
		expected = new char[22];
		expected[0] ='|';
		expected[21] ='|';
		assertArrayEquals(expected, canvas.getRow(4));
		canvas.clear();
	}
	
}
