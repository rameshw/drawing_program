package com.ramesh.cs;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class CanvasTest {
	private Canvas canvas;
	
	@Before
	public void init(){
		canvas = new Canvas();
		canvas.init(20,4);
	}
	
	@Test 
	public void testValidateLocationOnCanvas() {
		assertEquals(true, canvas.validateLocation(20,4));
		assertEquals(false, canvas.validateLocation(0,0));
		assertEquals(true, canvas.validateLocation(1,1));
		assertEquals(false, canvas.validateLocation(-1,-1));
		assertEquals(false, canvas.validateLocation(21,4));
		assertEquals(false, canvas.validateLocation(20,5));
		assertEquals(false, canvas.validateLocation(1,-1));
		assertEquals(false, canvas.validateLocation(-1,1));
	}

}
